 DROP TABLE  #__rubriestav_user;
 